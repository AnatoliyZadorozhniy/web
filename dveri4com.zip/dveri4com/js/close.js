$(document).click(function(e)
{
if ($(e.target).closest(".bg").length==0)
return;
$("#popup1").hide();
$("#popup2").hide();
});
